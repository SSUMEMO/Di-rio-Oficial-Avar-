"""
scraper.py - Coletor inicial do Diário Oficial Inteligente de Avaré

Etapa 1: exploração e coleta.
Coleta atos do Diário Oficial de Avaré nas listas públicas de Leis, Decretos e Portarias.

Como rodar:
    python src/scraper.py --limite 20
    python src/scraper.py --categorias Leis Decretos Portarias --limite 50
"""

from __future__ import annotations

import argparse
import re
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional
from urllib.parse import quote, urljoin

import pandas as pd
import requests
from bs4 import BeautifulSoup

BASE_SITE = "https://imprensaoficialmunicipal.com.br"
BASE_DOSP = "https://www.dosp.com.br"
MUNICIPIO = "Avaré"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; ProjetoFEAP-DiarioAvare/1.0; +https://github.com/)"
}


def inferir_secretaria(titulo: str) -> str:
    """Tenta inferir o órgão responsável a partir de palavras-chave do título."""
    t = titulo.lower()
    regras = [
        ("saúde", "Secretaria Municipal da Saúde"),
        ("saude", "Secretaria Municipal da Saúde"),
        ("educação", "Secretaria Municipal da Educação"),
        ("educacao", "Secretaria Municipal da Educação"),
        ("semads", "Secretaria Municipal de Assistência e Desenvolvimento Social"),
        ("assistência", "Secretaria Municipal de Assistência e Desenvolvimento Social"),
        ("serviços", "Secretaria Municipal de Serviços"),
        ("servicos", "Secretaria Municipal de Serviços"),
        ("planejamento", "Secretaria Municipal de Planejamento"),
        ("meio ambiente", "Secretaria Municipal do Meio Ambiente"),
        ("agricultura", "Secretaria Municipal de Agricultura e Abastecimento"),
        ("câmara", "Câmara Municipal"),
        ("camara", "Câmara Municipal"),
    ]
    for chave, secretaria in regras:
        if chave in t:
            return secretaria
    return "Não identificado"


def inferir_tipo_ato(categoria: str, titulo: str) -> str:
    """Define o tipo do ato com base na categoria e no título."""
    titulo_lower = titulo.lower()
    if "complementar" in titulo_lower or re.match(r"^\s*\d+\s*-", titulo_lower) and categoria.lower().startswith("leis"):
        # Mantém a maioria como Lei; só marca complementar quando o texto deixa claro.
        if "lei complementar" in titulo_lower:
            return "Lei Complementar"
    if categoria.lower().startswith("decreto"):
        return "Decreto"
    if categoria.lower().startswith("portaria"):
        return "Portaria"
    return "Lei"


def normalizar_data(data_br: str) -> str:
    """Converte dd/mm/aaaa para aaaa-mm-dd. Se falhar, retorna o texto original."""
    m = re.search(r"(\d{2})/(\d{2})/(\d{4})", data_br)
    if not m:
        return data_br.strip()
    dia, mes, ano = m.groups()
    return f"{ano}-{mes}-{dia}"


def montar_url_lista(categoria: str) -> str:
    municipio_encoded = quote(MUNICIPIO, safe="")
    categoria_encoded = quote(categoria, safe="")
    return f"{BASE_SITE}/listaatos.php?c={municipio_encoded}&s={categoria_encoded}"


def requisitar_html(url: str, timeout: int = 20) -> str:
    resp = requests.get(url, headers=HEADERS, timeout=timeout)
    resp.raise_for_status()
    return resp.text


def link_preferencial(row) -> str:
    """Escolhe o link de texto HTML quando existir; caso contrário usa o PDF da edição."""
    links = []
    for a in row.find_all("a", href=True):
        texto = a.get_text(" ", strip=True).lower()
        href = a["href"]
        absoluto = urljoin(BASE_SITE, href)
        if "dosp.com.br" not in absoluto and absoluto.startswith("/"):
            absoluto = urljoin(BASE_DOSP, absoluto)
        links.append((texto, absoluto))

    for texto, href in links:
        if "visualizar" in texto or "leitura" in href:
            return href
    for texto, href in links:
        if "abrir" in texto or "exibe_do" in href:
            return href
    return ""


def extrair_de_tabela(soup: BeautifulSoup, categoria: str) -> List[Dict[str, str]]:
    """Extrai registros quando o site retorna linhas HTML tabulares."""
    registros: List[Dict[str, str]] = []
    for tr in soup.find_all("tr"):
        cols = [td.get_text(" ", strip=True) for td in tr.find_all(["td", "th"])]
        if len(cols) < 4:
            continue
        texto_linha = " ".join(cols).lower()
        if "título" in texto_linha and "edição" in texto_linha:
            continue

        titulo = cols[0].strip()
        data = cols[1].strip() if len(cols) > 1 else ""
        edicao = cols[2].strip() if len(cols) > 2 else ""
        if not titulo or not re.search(r"\d{2}/\d{2}/\d{4}", data):
            continue

        url_doc = link_preferencial(tr)
        registros.append({
            "data_publicacao": normalizar_data(data),
            "numero_edicao": re.sub(r"\D", "", edicao),
            "titulo_ato": titulo,
            "tipo_ato": inferir_tipo_ato(categoria, titulo),
            "url_documento": url_doc,
            "secretaria": inferir_secretaria(titulo),
        })
    return registros


def extrair_fallback_texto(soup: BeautifulSoup, categoria: str) -> List[Dict[str, str]]:
    """Fallback simples: tenta reconhecer linhas no texto bruto da página."""
    registros: List[Dict[str, str]] = []
    texto = soup.get_text("\n", strip=True)
    padrao = re.compile(
        r"(?P<titulo>.+?)\s+(?P<data>\d{2}/\d{2}/\d{4})\s+(?P<edicao>\d{3,5})\s+(?P<ano>\d{1,3})",
        flags=re.MULTILINE,
    )
    for m in padrao.finditer(texto):
        titulo = m.group("titulo").strip(" -")
        if len(titulo) < 5 or titulo.lower() in {"título", "titulo"}:
            continue
        registros.append({
            "data_publicacao": normalizar_data(m.group("data")),
            "numero_edicao": m.group("edicao"),
            "titulo_ato": titulo,
            "tipo_ato": inferir_tipo_ato(categoria, titulo),
            "url_documento": "",
            "secretaria": inferir_secretaria(titulo),
        })
    return registros


def coletar_categoria(categoria: str, limite: Optional[int] = None) -> List[Dict[str, str]]:
    url = montar_url_lista(categoria)
    print(f"Coletando {categoria}: {url}")
    html = requisitar_html(url)
    soup = BeautifulSoup(html, "html.parser")

    registros = extrair_de_tabela(soup, categoria)
    if not registros:
        print("Aviso: nenhuma linha tabular encontrada. Tentando fallback por texto bruto...")
        registros = extrair_fallback_texto(soup, categoria)

    if limite:
        registros = registros[:limite]
    print(f"{len(registros)} registros encontrados em {categoria}.")
    return registros


def coletar_publicacoes(categorias: Iterable[str], limite_total: int) -> pd.DataFrame:
    todos: List[Dict[str, str]] = []
    for categoria in categorias:
        restantes = max(limite_total - len(todos), 0)
        if restantes == 0:
            break
        todos.extend(coletar_categoria(categoria, limite=restantes))
        time.sleep(1)  # evita requisições muito rápidas ao site

    df = pd.DataFrame(todos)
    colunas = ["data_publicacao", "numero_edicao", "titulo_ato", "tipo_ato", "url_documento", "secretaria"]
    for c in colunas:
        if c not in df.columns:
            df[c] = ""
    return df[colunas].drop_duplicates()


def salvar_csv(df: pd.DataFrame, saida: Path) -> None:
    saida.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(saida, index=False, encoding="utf-8-sig")
    print(f"Arquivo salvo em: {saida}")
    print(f"Total de publicações salvas: {len(df)}")
    print(df.head())


def main() -> None:
    parser = argparse.ArgumentParser(description="Coletor inicial do Diário Oficial de Avaré")
    parser.add_argument("--limite", type=int, default=20, help="Quantidade mínima/máxima de registros a salvar")
    parser.add_argument("--saida", default="data/diario_avare.csv", help="Caminho do CSV de saída")
    parser.add_argument(
        "--categorias",
        nargs="+",
        default=["Leis", "Decretos", "Portarias"],
        help="Categorias do menu Listar Atos a coletar",
    )
    args = parser.parse_args()

    df = coletar_publicacoes(args.categorias, args.limite)
    if len(df) < args.limite:
        print(f"Aviso: foram coletados {len(df)} registros, menos que o limite solicitado ({args.limite}).")
    salvar_csv(df, Path(args.saida))


if __name__ == "__main__":
    main()
