# src/extract_text.py
# Responsavel: extrair texto de PDFs/HTML e montar a base textual limpa.
# Projeto: Diario Oficial Inteligente de Avare - Etapa 2

from __future__ import annotations

import argparse
import csv
import io
import os
import re
import sqlite3
import zipfile
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import urlparse

import pdfplumber
import requests
from bs4 import BeautifulSoup

try:
    from preprocess import corrigir_mojibake, inferir_rotulo, processar, texto_fallback
except ImportError:
    from src.preprocess import corrigir_mojibake, inferir_rotulo, processar, texto_fallback


NS = {"a": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def excel_serial_para_data(valor) -> str:
    """Converte numero serial do Excel para YYYY-MM-DD."""
    if isinstance(valor, (int, float)):
        return (datetime(1899, 12, 30) + timedelta(days=int(valor))).strftime("%Y-%m-%d")
    texto = str(valor).strip()
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(texto, fmt).strftime("%Y-%m-%d")
        except ValueError:
            pass
    return texto


def ler_xlsx_simples(caminho: str) -> list[dict]:
    """Le um .xlsx sem depender de openpyxl, suficiente para a planilha da Etapa 1."""
    with zipfile.ZipFile(caminho) as z:
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root.findall("a:si", NS):
                partes = [t.text or "" for t in si.findall(".//a:t", NS)]
                shared.append("".join(partes))

        sheet = ET.fromstring(z.read("xl/worksheets/sheet1.xml"))
        linhas = []
        for row in sheet.findall(".//a:sheetData/a:row", NS):
            celulas = {}
            for c in row.findall("a:c", NS):
                ref = c.attrib.get("r", "")
                letras = "".join(ch for ch in ref if ch.isalpha())
                indice = 0
                for ch in letras:
                    indice = indice * 26 + (ord(ch.upper()) - 64)

                tipo = c.attrib.get("t")
                v = c.find("a:v", NS)
                if tipo == "s":
                    valor = shared[int(v.text)] if v is not None and v.text is not None else ""
                elif tipo == "inlineStr":
                    valor = "".join(t.text or "" for t in c.findall(".//a:t", NS))
                else:
                    valor = v.text if v is not None and v.text is not None else ""
                    if re.fullmatch(r"-?\d+(\.\d+)?", str(valor)):
                        valor = float(valor)
                celulas[indice] = corrigir_mojibake(valor)

            if celulas:
                largura = max(celulas)
                linhas.append([celulas.get(i, "") for i in range(1, largura + 1)])

    cabecalhos = [str(corrigir_mojibake(h)).replace("\ufeff", "") for h in linhas[0]]
    registros = []
    for linha in linhas[1:]:
        item = dict(zip(cabecalhos, linha))
        item["data_publicacao"] = excel_serial_para_data(item.get("data_publicacao", ""))
        item["numero_edicao"] = int(float(item.get("numero_edicao", 0) or 0))
        registros.append(item)

    return registros


def baixar_url(url: str, pasta_destino: Path) -> tuple[bytes, str]:
    """Baixa URL e retorna conteudo bruto + content-type."""
    pasta_destino.mkdir(parents=True, exist_ok=True)
    nome = re.sub(r"[^A-Za-z0-9]+", "_", urlparse(url).query or urlparse(url).path).strip("_") or "documento"
    destino = pasta_destino / f"{nome}.bin"

    if destino.exists():
        return destino.read_bytes(), ""

    resposta = requests.get(url, timeout=30, headers={"User-Agent": "ProjetoFEAP/1.0"})
    resposta.raise_for_status()
    destino.write_bytes(resposta.content)
    return resposta.content, resposta.headers.get("Content-Type", "")


def extrair_de_pdf_bytes(conteudo: bytes) -> str:
    """Extrai texto de PDF digital com pdfplumber."""
    partes = []
    with pdfplumber.open(io.BytesIO(conteudo)) as pdf:
        for pagina in pdf.pages:
            texto = pagina.extract_text() or ""
            if texto.strip():
                partes.append(texto)
    return "\n".join(partes)


def extrair_de_html_bytes(conteudo: bytes) -> str:
    """Extrai texto de uma pagina HTML com BeautifulSoup."""
    soup = BeautifulSoup(conteudo, "html.parser")
    for tag in soup(["script", "style", "nav", "header", "footer"]):
        tag.decompose()
    return soup.get_text(separator="\n", strip=True)


def extrair_texto_url(url: str, pasta_raw: Path) -> str:
    """Detecta PDF/HTML e extrai texto limpo."""
    conteudo, content_type = baixar_url(url, pasta_raw)

    parece_pdf = content_type.lower().startswith("application/pdf") or conteudo[:4] == b"%PDF"
    if parece_pdf:
        texto = extrair_de_pdf_bytes(conteudo)
    else:
        texto = extrair_de_html_bytes(conteudo)

    return processar(texto)


def recortar_trecho_por_titulo(texto_documento: str, titulo: str, tamanho: int = 3500) -> str:
    """Tenta localizar o ato dentro do Diario completo usando numero do ato."""
    if not texto_documento:
        return ""

    titulo_limpo = re.sub(r"^\s*\d+\s*[-–]\s*", "", titulo).strip()
    numeros = re.findall(r"\d{3,5}", titulo)
    candidatos = []

    for numero in numeros[:2]:
        candidatos.extend([
            rf"Lei\s+(?:n[ºo]\.?\s*)?{re.escape(numero)}",
            rf"Decreto\s+(?:n[ºo]\.?\s*)?{re.escape(numero)}",
            rf"Portaria\s+(?:n[ºo]\.?\s*)?{re.escape(numero)}",
            re.escape(numero),
        ])

    palavras = [p for p in re.split(r"\W+", titulo_limpo) if len(p) > 5]
    if palavras:
        candidatos.append(re.escape(" ".join(palavras[:4])))

    for padrao in candidatos:
        m = re.search(padrao, texto_documento, flags=re.IGNORECASE)
        if m:
            ini = max(0, m.start() - 200)
            fim = min(len(texto_documento), m.start() + tamanho)
            return processar(texto_documento[ini:fim])

    return processar(texto_documento[:tamanho])



def extrair_atos_adicionais(texto_documento: str, url: str, data_publicacao: str, numero_edicao: int, titulos_existentes: set[str]) -> list[dict]:
    """Quebra um Diario completo em atos extras quando a planilha tem menos de 40 itens.

    A heuristica procura cabecalhos de atos comuns no Diario Oficial.
    Depois, cada trecho vira um registro para revisao manual.
    """
    if not texto_documento:
        return []

    padrao = re.compile(
        r"(?im)^(?:"
        r"Lei\s+Complementar\s+n[ºo]\.?\s*[\d./-]+.*|"
        r"Lei\s+n[ºo]\.?\s*[\d./-]+.*|"
        r"Decreto\s+n[ºo]\.?\s*[\d./-]+.*|"
        r"Portaria\s+n[ºo]\.?\s*[\d./-]+.*|"
        r"PREGÃO\s+ELETRÔNICO\s+n[ºo]\.?\s*[\d./-]+.*|"
        r"Pregão\s+Eletrônico\s+n[ºo]\.?\s*[\d./-]+.*|"
        r"CHAMAMENTO\s+PÚBLICO\s+n[ºo]\.?\s*[\d./-]+.*|"
        r"DISPENSA\s+ELETRÔNICA\s+n[ºo]\.?\s*[\d./-]+.*|"
        r"INEXIGIBILIDADE\s+n[ºo]\.?\s*[\d./-]+.*|"
        r"EXTRATO\s+DE\s+(?:ATA|CONTRATO).*|"
        r"ADJUDICAÇÃO.*|"
        r"HOMOLOGAÇÃO.*|"
        r"CONVOCAÇÃO.*|"
        r"OFÍCIO\s+.*|"
        r"Ata\s+n[ºo]\.?\s*[\d./-]+.*"
        r")$"
    )

    matches = list(padrao.finditer(texto_documento))
    extras = []

    for idx, m in enumerate(matches):
        titulo = processar(m.group(0))
        chave = re.sub(r"\W+", " ", titulo.lower()).strip()
        if chave in titulos_existentes or len(titulo) < 8:
            continue

        fim = matches[idx + 1].start() if idx + 1 < len(matches) else min(len(texto_documento), m.start() + 3500)
        trecho = processar(texto_documento[m.start():fim])
        if len(trecho) < 120:
            continue

        if titulo.lower().startswith("lei complementar"):
            tipo = "Lei Complementar"
        elif titulo.lower().startswith("lei"):
            tipo = "Lei"
        elif titulo.lower().startswith("decreto"):
            tipo = "Decreto"
        elif titulo.lower().startswith("portaria"):
            tipo = "Portaria"
        elif any(p in titulo.lower() for p in ["pregão", "chamamento", "dispensa", "inexigibilidade", "extrato", "adjudicação", "homologação"]):
            tipo = "Licitação/Contrato"
        else:
            tipo = "Outros Atos"

        rotulo = inferir_rotulo(tipo, titulo, trecho)
        extras.append({
            "data_publicacao": data_publicacao,
            "numero_edicao": numero_edicao,
            "tipo_ato": tipo,
            "titulo": titulo,
            "secretaria": "Não identificado",
            "texto": trecho,
            "url_original": url,
            "rotulo": rotulo,
        })
        titulos_existentes.add(chave)

    return extras


def montar_base(caminho_entrada: str, pasta_saida: str, limite_amostra: int = 40) -> list[dict]:
    pasta_saida = Path(pasta_saida)
    pasta_saida.mkdir(parents=True, exist_ok=True)
    pasta_raw = pasta_saida.parent / "raw" / "documentos"
    pasta_raw.mkdir(parents=True, exist_ok=True)

    metadados = ler_xlsx_simples(caminho_entrada)
    cache_textos = {}
    registros = []

    for i, item in enumerate(metadados, start=1):
        url = item.get("url_documento", "")
        titulo = corrigir_mojibake(item.get("titulo_ato", ""))
        tipo_ato = corrigir_mojibake(item.get("tipo_ato", ""))
        secretaria = corrigir_mojibake(item.get("secretaria", "Não identificado"))
        data_publicacao = item.get("data_publicacao", "")
        numero_edicao = item.get("numero_edicao", "")

        if url not in cache_textos:
            try:
                cache_textos[url] = extrair_texto_url(url, pasta_raw)
            except Exception as exc:
                print(f"[AVISO] Falha ao extrair {url}: {exc}")
                cache_textos[url] = ""

        trecho = recortar_trecho_por_titulo(cache_textos[url], titulo)
        rotulo = inferir_rotulo(tipo_ato, titulo, trecho)

        if len(trecho) < 120:
            trecho = texto_fallback(tipo_ato, titulo, data_publicacao, secretaria, rotulo)

        registros.append({
            "id": f"DOA-2026-{i:03d}",
            "data_publicacao": data_publicacao,
            "numero_edicao": numero_edicao,
            "tipo_ato": tipo_ato,
            "titulo": titulo,
            "secretaria": secretaria,
            "texto": trecho,
            "url_original": url,
            "rotulo": rotulo,
        })

    # Se a planilha inicial tiver poucos registros, expande os Diarios completos
    # em atos adicionais para atingir a amostra minima de 40 itens.
    titulos_existentes = {re.sub(r"\W+", " ", r["titulo"].lower()).strip() for r in registros}
    if len(registros) < limite_amostra:
        proximo = len(registros) + 1
        for item in metadados:
            url = item.get("url_documento", "")
            texto_doc = cache_textos.get(url, "")
            extras = extrair_atos_adicionais(
                texto_doc,
                url,
                item.get("data_publicacao", ""),
                item.get("numero_edicao", ""),
                titulos_existentes,
            )
            for extra in extras:
                extra["id"] = f"DOA-2026-{proximo:03d}"
                registros.append(extra)
                proximo += 1
                if len(registros) >= limite_amostra:
                    break
            if len(registros) >= limite_amostra:
                break

    campos = [
        "id", "data_publicacao", "numero_edicao", "tipo_ato", "titulo",
        "secretaria", "texto", "url_original", "rotulo"
    ]

    base_csv = pasta_saida / "base_textual.csv"
    with base_csv.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=campos)
        writer.writeheader()
        writer.writerows(registros)

    amostra = [r for r in registros if r.get("rotulo")][:limite_amostra]
    amostra_csv = pasta_saida / "amostra_rotulada.csv"
    with amostra_csv.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=campos)
        writer.writeheader()
        writer.writerows(amostra)

    db_path = pasta_saida / "diario_avare.db"
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("DROP TABLE IF EXISTS publicacoes")
    cur.execute("""
        CREATE TABLE publicacoes (
            id TEXT PRIMARY KEY,
            data_publicacao TEXT,
            numero_edicao INTEGER,
            tipo_ato TEXT,
            titulo TEXT,
            secretaria TEXT,
            texto TEXT,
            url_original TEXT,
            rotulo TEXT
        )
    """)
    cur.executemany(
        "INSERT INTO publicacoes VALUES (?,?,?,?,?,?,?,?,?)",
        [[r[c] for c in campos] for r in registros],
    )
    conn.commit()
    conn.close()

    return registros


def main():
    parser = argparse.ArgumentParser(description="Extrai, limpa e estrutura publicacoes do Diario Oficial de Avare.")
    parser.add_argument("--input", default="data/raw/diario_avare.xlsx", help="Planilha gerada na Etapa 1")
    parser.add_argument("--output", default="data/processed", help="Pasta de saida")
    parser.add_argument("--sample-size", type=int, default=40, help="Quantidade minima da amostra rotulada")
    args = parser.parse_args()

    registros = montar_base(args.input, args.output, args.sample_size)
    print(f"Base textual gerada com {len(registros)} registros em {args.output}")


if __name__ == "__main__":
    main()
