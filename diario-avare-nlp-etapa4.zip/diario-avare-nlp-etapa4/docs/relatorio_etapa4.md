# Relatorio da Etapa 4 - Modelo, Avaliacao e Aplicacao

## Identificacao

**Projeto:** Diario Oficial Inteligente de Avare  
**Disciplina:** Redes Neurais e IA Aplicada  
**Instituicao:** FEAP - Engenharia de Computacao  
**Grupo:** 8  
**Turma / Periodo:** 7º Termo - Engenharia da Computacao  
**Repositorio GitHub:** https://github.com/SSUMEMO/Di-rio-Oficial-Avar-

| Integrante | RA | Nome |
|---|---|---|
| 1 | Sem RA | Gabriel Joaquim Carlos de Andrade Rodrigues |
| 2 | Sem RA | Marcos Paulo Candido |
| 3 | Sem RA | Willian Eduardo Novaes |

## 1. Objetivo da etapa

A Etapa 4 fecha o projeto pratico com um sistema completo de classificacao textual. A partir dos arquivos gerados na Etapa 3 (`vocab.json`, `label_map.json` e `src/dataset.py`), foi criado um modelo neural em PyTorch, treinado com os textos rotulados, avaliado no conjunto de teste e conectado a uma interface Streamlit.

O fluxo final ficou assim:

1. texto da publicacao;
2. tokenizacao e codificacao com o vocabulario da Etapa 3;
3. classificacao por rede neural com embeddings;
4. exibicao da classe prevista e da confianca no app.

## 2. Arquitetura do modelo

Arquivo principal: `src/model.py`.

O modelo implementado foi o `ClassificadorDiario`, seguindo a arquitetura pedida no guia:

- `nn.Embedding` com `padding_idx=0`, usando o token `<PAD>`;
- media dos vetores de palavras para representar o texto inteiro;
- camada linear intermediaria com ReLU;
- dropout para reduzir overfitting;
- camada linear final com um logit por classe.

Hiperparametros usados:

| Parametro | Valor |
|---|---:|
| Tamanho do vocabulario | 159 |
| Numero de classes | 5 |
| `max_len` | 60 |
| `embed_dim` | 64 |
| `hidden_dim` | 128 |
| `dropout` | 0.2 |
| Batch size | 8 |
| Epocas | 20 |
| Learning rate | 0.001 |
| Otimizador | Adam |
| Funcao de perda | CrossEntropyLoss |

A media de embeddings foi escolhida porque e uma arquitetura simples, rapida e adequada para uma base pequena, principalmente quando as classes possuem termos administrativos caracteristicos, como `pregao`, `decreto`, `portaria`, `receita` e `despesa`.

## 3. Dados usados no treinamento

Total de registros rotulados: **53**.

Divisao final:

- Treino: **42** registros;
- Teste: **11** registros.

Distribuicao no treino:

- `decreto`: 18
- `contas_publicas`: 12
- `licitacao_contrato`: 8
- `portaria`: 3
- `ato_pessoal`: 1

Distribuicao no teste:

- `decreto`: 5
- `contas_publicas`: 3
- `licitacao_contrato`: 2
- `portaria`: 1

Observacao importante: a classe `ato_pessoal` possui apenas 1 registro na base rotulada. Por isso, ela foi mantida no treino e ficou sem exemplos no teste. Essa limitacao afeta a avaliacao do f1-score dessa classe e deve ser corrigida em uma versao futura com mais dados rotulados.

## 4. Treinamento

O treinamento foi realizado no notebook `notebooks/04_treinamento_avaliacao.ipynb` por **20 epocas**.

A perda inicial foi **1.6250** e a perda final foi **0.2237**, indicando convergencia do treinamento.

Grafico salvo em:

`docs/curva_treinamento.png`

![Curva de treinamento](curva_treinamento.png)

## 5. Avaliacao no conjunto de teste

A acuracia obtida no conjunto de teste foi:

**90.91%**

Relatorio por classe:

```text
                    precision    recall  f1-score   support

       ato_pessoal       0.00      0.00      0.00         0
   contas_publicas       1.00      1.00      1.00         3
           decreto       0.83      1.00      0.91         5
licitacao_contrato       1.00      1.00      1.00         2
          portaria       0.00      0.00      0.00         1

          accuracy                           0.91        11
         macro avg       0.57      0.60      0.58        11
      weighted avg       0.83      0.91      0.87        11

```

Matriz de confusao salva em:

`docs/matriz_confusao.png`

![Matriz de confusao](matriz_confusao.png)

A acuracia foi boa para a base pequena, mas deve ser interpretada com cuidado. A amostra tem apenas 53 registros e classes desbalanceadas. Por isso, o f1-score por classe e a matriz de confusao sao mais importantes do que a acuracia isolada.

## 6. Analise qualitativa de erros e casos de atencao

- **Erro real:** classe correta `portaria`, previsto `decreto`, confiança `36.41%`. Título: Ata nº 003/2026 - reunião ordinária do Conselho Municipal dos Direitos da Pessoa com Deficiência. Trecho: Outros Atos nº 003, de 19/05/2026. Ementa: Ata nº 003/2026 - reunião ordinária do Conselho Municipal dos Direitos da Pessoa com Deficiência. Secretaria/órgão: Conselho Municipal dos Direitos da Pessoa com Deficiência. Portaria expedida pela Administração Municipal. Resolve discip...
- **Caso de atenção:** classe correta `contas_publicas`, previsto `contas_publicas`, confiança `75.88%`. Apesar do acerto, a confiança foi uma das menores do teste. Título: 3439 - revisão das alíquotas adicionais - contribuição previdenciária - déficit atuarial. Trecho: Lei nº 3439, de 08/05/2026. Ementa: revisão das alíquotas adicionais - contribuição previdenciária - déficit atuarial. Secretaria/órgão: órgão municipal responsável não identificado no metadado. Dispõe sobre abertura de crédito adicional e adequação de dotações orçamentárias. ROB...
- **Caso de atenção:** classe correta `licitacao_contrato`, previsto `licitacao_contrato`, confiança `85.18%`. Apesar do acerto, a confiança foi uma das menores do teste. Título: Chamamento Público nº 004/2026 - credenciamento para consultas em psiquiatria. Trecho: Licitação/Contrato nº 004, de 04/05/2026. Ementa: Chamamento Público nº 004/2026 - credenciamento para consultas em psiquiatria. Secretaria/órgão: Departamento de Licitação. Aviso/ato referente a procedimento administrativo de contratação pública. Constam modalidade, processo, ob...

Conclusoes da analise:

- a classe `portaria` tem poucos exemplos e pode ser confundida com `decreto`, pois ambas usam linguagem normativa;
- a classe `ato_pessoal` precisa de mais registros para ser avaliada corretamente no teste;
- textos muito curtos ou genéricos tendem a gerar menor confianca;
- a proxima melhoria seria ampliar a amostra rotulada, especialmente para `ato_pessoal`, `portaria` e `edital_concurso`.

## 7. Inferencia

Arquivo principal: `src/inferencia.py`.

A funcao `classificar(texto)` carrega:

- `data/processed/vocab.json`;
- `data/processed/label_map.json`;
- `models/modelo.pt`;
- a mesma tokenizacao/codificacao da Etapa 3.

Ela retorna:

- classe prevista;
- confianca da previsao;
- ranking das 3 classes mais provaveis.

Exemplo de uso:

```python
from src.inferencia import classificar

classe, confianca, ranking = classificar('Pregao eletronico para registro de precos de medicamentos')
print(classe, confianca, ranking)
```

## 8. Interface do usuario

Arquivo principal: `app.py`.

A interface foi feita com Streamlit e possui tres abas:

1. **Classificador:** o usuario cola o texto e recebe a classe prevista com confianca;
2. **Busca de publicacoes:** permite filtrar a base rotulada por classe e palavra-chave;
3. **Painel de indicadores:** mostra total de publicacoes, numero de classes, acuracia e distribuicao por classe.

Para executar:

```bash
streamlit run app.py
```

A interface atende ao requisito principal da etapa: permitir que uma pessoa use o modelo real sem precisar mexer diretamente em Python.

## 9. Limitacoes

As principais limitacoes do projeto sao:

- base pequena para treinamento de rede neural;
- forte desbalanceamento entre as classes;
- classe `ato_pessoal` com apenas 1 exemplo;
- possibilidade de textos fallback em alguns registros, quando a extracao textual original nao era suficiente;
- modelo simples baseado em media de embeddings, sem considerar ordem completa das palavras.

Essas limitacoes nao invalidam o projeto; elas mostram os pontos que devem ser melhorados antes de uso real em producao.

## 10. Evolucao futura

Com mais tempo e dados, o sistema poderia evoluir para:

- ampliar a base rotulada para pelo menos 50 exemplos por classe;
- testar LSTM, GRU ou Transformers;
- criar alertas automaticos por classe ou palavra-chave;
- implementar busca semantica;
- extrair entidades como empresas, valores, datas e secretarias;
- publicar a interface em um servidor acessivel ao publico.

## 11. Entregaveis da Etapa 4

| Entregavel | Caminho |
|---|---|
| Modelo | `src/model.py` |
| Pesos treinados | `models/modelo.pt` |
| Notebook de treinamento e avaliacao | `notebooks/04_treinamento_avaliacao.ipynb` |
| Interface | `app.py` |
| Relatorio | `docs/relatorio_etapa4.md` |
| Curva de treinamento | `docs/curva_treinamento.png` |
| Matriz de confusao | `docs/matriz_confusao.png` |
| Inferencia | `src/inferencia.py` |

## 12. Conclusao

A Etapa 4 transformou o conjunto de dados preparado nas etapas anteriores em uma aplicacao funcional. O grupo construiu um modelo PyTorch simples e explicavel, avaliou seus resultados, registrou as limitacoes e criou uma interface para demonstrar o classificador em funcionamento.
