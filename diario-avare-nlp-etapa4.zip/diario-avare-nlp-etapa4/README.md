# Diario Oficial Inteligente de Avare - Etapa 4

Projeto pratico da disciplina **Redes Neurais e IA Aplicada** - FEAP Engenharia de Computacao.

## Identificacao

- **Grupo:** 8
- **Turma / Periodo:** 7º Termo - Engenharia da Computacao
- **Repositorio:** https://github.com/SSUMEMO/Di-rio-Oficial-Avar-
- **Integrantes:**
  - Gabriel Joaquim Carlos de Andrade Rodrigues - RA: Sem RA
  - Marcos Paulo Candido - RA: Sem RA
  - Willian Eduardo Novaes - RA: Sem RA

## Objetivo da Etapa 4

Treinar um modelo PyTorch para classificar publicacoes do Diario Oficial de Avare, avaliar os resultados e disponibilizar uma interface simples para uso do classificador.

## Entregaveis principais

- `src/model.py` - modelo neural com `nn.Embedding`, media dos embeddings e camadas lineares.
- `models/modelo.pt` - pesos treinados do modelo.
- `notebooks/04_treinamento_avaliacao.ipynb` - notebook com treinamento e avaliacao.
- `src/inferencia.py` - funcao `classificar(texto)` para uso do modelo.
- `app.py` - interface Streamlit.
- `docs/relatorio_etapa4.md` - relatorio final da etapa.
- `docs/curva_treinamento.png` - curva de perda por epoca.
- `docs/matriz_confusao.png` - matriz de confusao no teste.

## Resultados

- Registros rotulados: 53
- Registros de treino: 42
- Registros de teste: 11
- Vocabulario: 159 tokens
- `max_len`: 60
- Acuracia no teste: 90,91%
- Modelo treinado por 20 epocas com Adam e CrossEntropyLoss.

## Como instalar

```bash
pip install -r requirements.txt
```

## Como testar o modelo no terminal

```bash
python src/inferencia.py
```

## Como rodar a interface

```bash
streamlit run app.py
```

A interface possui tres abas:

1. Classificador de publicacoes;
2. Busca na base rotulada;
3. Painel de indicadores.

## Estrutura final

```text
diario-avare-nlp/
|-- data/
|   |-- processed/
|       |-- base_textual.csv
|       |-- amostra_rotulada.csv
|       |-- vocab.json
|       |-- label_map.json
|       |-- treino_etapa4.csv
|       |-- teste_etapa4.csv
|-- models/
|   |-- modelo.pt
|-- docs/
|   |-- relatorio_etapa4.md
|   |-- curva_treinamento.png
|   |-- matriz_confusao.png
|   |-- roteiro_apresentacao_etapa4.md
|-- notebooks/
|   |-- 04_treinamento_avaliacao.ipynb
|-- src/
|   |-- dataset.py
|   |-- model.py
|   |-- inferencia.py
|-- app.py
|-- requirements.txt
```
