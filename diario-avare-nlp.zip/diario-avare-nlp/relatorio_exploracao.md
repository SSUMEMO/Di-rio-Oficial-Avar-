# Relatório de Exploração da Fonte

**Projeto:** Diário Oficial Inteligente de Avaré  
**Disciplina:** Redes Neurais e IA Aplicada  
**Etapa:** Semana 1 - Exploração e Coleta

## 1. Identificação do grupo

> Atenção: preencher todos os campos antes da entrega no GitHub.

| Campo | Informação |
|---|---|
| Número do grupo | PREENCHER |
| Turma / Período | PREENCHER |
| Integrante 1 (RA \| Nome) | PREENCHER \| Gabriel Joaquim Carlos de Andrade Rodrigues |
| Integrante 2 (RA \| Nome) | PREENCHER |
| Integrante 3 (RA \| Nome) | PREENCHER |
| Integrante 4 (RA \| Nome) | PREENCHER |
| Integrante 5 (RA \| Nome) | PREENCHER |
| Repositório GitHub | PREENCHER |

## 2. Objetivo da etapa

A Semana 1 tem como objetivo explorar o site do Diário Oficial de Avaré, entender a estrutura de navegação e criar um primeiro coletor automatizado em Python. O resultado esperado é uma lista preliminar de publicações em CSV com metadados básicos, além do script `scraper.py` e deste relatório.

## 3. Fonte explorada

A fonte principal analisada foi o portal do Diário Oficial Eletrônico do Município de Avaré:

- `https://imprensaoficialmunicipal.com.br/avare`

Também foram analisadas páginas auxiliares do próprio portal:

- Pesquisa: `https://imprensaoficialmunicipal.com.br/pesquisar.php?c=avare`
- Lista de Leis: `https://imprensaoficialmunicipal.com.br/listaatos.php?c=Avar%C3%A9&s=Leis`
- Lista de Decretos: `https://imprensaoficialmunicipal.com.br/listaatos.php?c=Avar%C3%A9&s=Decretos`
- Lista de Portarias: `https://imprensaoficialmunicipal.com.br/listaatos.php?c=Avar%C3%A9&s=Portarias`

## 4. Estrutura de navegação encontrada

Na página inicial do Diário Oficial de Avaré existem opções de navegação como **Início**, **Pesquisar**, **Listar Atos**, **Lista de Leis**, **Lista de Decretos** e **Lista de Portarias**.

A página inicial também apresenta filtros por data e por seção. Entre as seções visíveis foram identificadas categorias como:

- Advertências / Notificações
- Atos Administrativos
- Atos de Pessoal
- Atos Legislativos
- Atos Oficiais
- Comunicados
- Concursos Públicos / Processos Seletivos
- Contas Públicas e Instrumentos de Gestão Fiscal
- Editais
- Licitações e Contratos
- Outros Atos
- Vigilância Sanitária

A área de **Listar Atos** se mostrou a mais útil para a primeira coleta, pois organiza atos específicos em linhas contendo título, data, número da edição, ano e links para o documento.

## 5. Tipos de documentos disponíveis

Foram encontrados dois formatos principais:

1. **PDF da edição oficial**  
   Link identificado como **Abrir Edição**. O padrão observado foi:
   `https://www.dosp.com.br/exibe_do.php?i=...`

2. **HTML em modo leitura**  
   Link identificado como **Visualizar**. O padrão observado foi:
   `https://www.dosp.com.br/leituratexto?p=...`

O PDF é a versão certificada/publicada da edição do Diário Oficial. O modo leitura em HTML facilita a extração de texto por ser mais limpo para processamento posterior.

## 6. Padrões de URL identificados

| Finalidade | Padrão observado |
|---|---|
| Página inicial | `https://imprensaoficialmunicipal.com.br/avare` |
| Pesquisa | `https://imprensaoficialmunicipal.com.br/pesquisar.php?c=avare` |
| Lista de atos | `https://imprensaoficialmunicipal.com.br/listaatos.php?c=Avar%C3%A9&s=Leis` |
| PDF da edição | `https://www.dosp.com.br/exibe_do.php?i=...` |
| Texto HTML do ato | `https://www.dosp.com.br/leituratexto?p=...` |

A variável `s` na URL da lista de atos muda conforme a categoria pesquisada, por exemplo: `Leis`, `Decretos` e `Portarias`.

## 7. Campos e metadados disponíveis

Nas listas de atos foram observados os seguintes campos:

| Campo no site | Uso no CSV |
|---|---|
| Título | `titulo_ato` |
| Data | `data_publicacao` |
| Edição | `numero_edicao` |
| Ano | Informação complementar, não incluída no CSV final |
| Diário Oficial / Abrir Edição | `url_documento` |
| Texto / Visualizar | pode ser usado como `url_documento` quando disponível |

O campo `secretaria` nem sempre aparece explicitamente. Por isso, no script inicial ele é inferido por palavras-chave no título, como saúde, educação, SEMADS, planejamento e serviços. Quando não é possível identificar, o valor usado é `Não identificado`.

## 8. Comparação com o projeto Acórdãos TCU

O projeto de referência **Acórdãos TCU** foi usado como inspiração conceitual, não como código a ser copiado.

| Aspecto | Acórdãos TCU | Diário Oficial de Avaré |
|---|---|---|
| Escala | Nacional/federal | Municipal |
| Tipo de documento | Acórdãos do Tribunal de Contas da União | Leis, decretos, portarias, licitações, editais e outros atos municipais |
| Complexidade | Alta, com grande volume histórico | Menor, adequado para projeto didático |
| Ferramentas citadas | Selenium e Scrapy | Inicialmente requests + BeautifulSoup; Playwright/Selenium apenas se necessário |
| Objetivo final | Dataset público de acórdãos | Dataset municipal para classificação textual com NLP e redes neurais |

A principal semelhança é o pipeline: localizar documentos públicos, coletar metadados, organizar os dados e preparar uma base reutilizável. A principal diferença é a escala e o domínio: o TCU lida com decisões federais e muitos anos de dados, enquanto o projeto de Avaré trabalha com publicações municipais recentes.

## 9. Decisão sobre a ferramenta de coleta

A ferramenta escolhida para a Etapa 1 foi:

**requests + BeautifulSoup + pandas**

Justificativa:

- As páginas de lista de atos retornam informações diretamente no HTML.
- A estrutura é simples o suficiente para uma primeira coleta.
- O uso de `requests` reduz complexidade e é mais leve que Selenium ou Playwright.
- `BeautifulSoup` permite localizar tabelas, linhas e links de forma direta.
- `pandas` facilita a organização e exportação para CSV.

O uso de Playwright ou Selenium fica como alternativa caso, nas próximas etapas, alguma informação dependa de JavaScript dinâmico, cliques, filtros ou carregamento posterior no navegador.

## 10. Dificuldades encontradas

Durante a exploração foram observadas algumas dificuldades:

- Algumas publicações possuem link de texto HTML, mas outras apresentam somente link para o PDF da edição.
- A secretaria responsável nem sempre aparece como campo separado.
- A URL do município possui acento em `Avaré`, exigindo atenção com codificação na montagem do link.
- Alguns títulos precisam de limpeza textual para padronização.
- O site pode ter páginas com estrutura diferente dependendo da categoria.

## 11. Estratégia adotada no script

O arquivo `src/scraper.py` foi construído para:

1. Acessar as páginas de listagem de atos.
2. Ler categorias como Leis, Decretos e Portarias.
3. Extrair os campos mínimos de cada linha encontrada.
4. Preferir o link HTML de visualização quando existir.
5. Usar o PDF da edição quando o texto HTML não estiver disponível.
6. Inferir a secretaria por palavras-chave.
7. Salvar os dados em `data/diario_avare.csv`.

## 12. CSV preliminar

Foi criado o arquivo:

- `data/diario_avare.csv`

Ele contém mais de 20 registros preliminares com os campos:

- `data_publicacao`
- `numero_edicao`
- `titulo_ato`
- `tipo_ato`
- `url_documento`
- `secretaria`

## 13. Conclusão

A fonte do Diário Oficial de Avaré é adequada para a Etapa 1 do projeto. A coleta inicial pode ser feita com `requests` e `BeautifulSoup`, principalmente a partir das páginas de listagem de atos. O CSV preliminar já permite iniciar a organização dos metadados e serve como base para as próximas semanas, quando o grupo deverá extrair textos completos, limpar o conteúdo e preparar os dados para NLP e redes neurais.
