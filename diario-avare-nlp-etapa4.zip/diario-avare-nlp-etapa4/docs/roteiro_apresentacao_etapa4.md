# Roteiro da Apresentacao Final - Etapa 4

**Grupo 8 - 7º Termo - Engenharia da Computacao**  
**Integrantes:** Gabriel Joaquim Carlos de Andrade Rodrigues, Marcos Paulo Candido e Willian Eduardo Novaes

## Tempo total: 10 minutos

### 1. Problema e objetivo (1 minuto)

- Explicar que o Diario Oficial possui muitas publicacoes em linguagem administrativa.
- Mostrar que a leitura manual e demorada para servidores, cidadaos, jornalistas e empresas.
- Objetivo do projeto: classificar automaticamente publicacoes por tipo, como decreto, licitacao, portaria e contas publicas.

### 2. Pipeline completo do projeto (2 minutos)

Falar rapidamente as quatro etapas:

1. **Etapa 1:** coleta das publicacoes e metadados.
2. **Etapa 2:** extracao, limpeza, estruturacao e rotulagem.
3. **Etapa 3:** tokenizacao, vocabulario, label encoding e Dataset PyTorch.
4. **Etapa 4:** treinamento do modelo, avaliacao e interface.

Frase de apoio:

> O projeto saiu do texto bruto do Diario Oficial e chegou ate uma tela em que qualquer pessoa pode colar uma publicacao e receber a classificacao automaticamente.

### 3. Modelo usado (1 minuto)

- Modelo em PyTorch.
- Arquitetura: `nn.Embedding`, media dos vetores e camadas lineares.
- Perda: `CrossEntropyLoss`.
- Otimizador: Adam.
- Treinamento: 20 epocas.
- Modelo salvo em `models/modelo.pt`.

### 4. Resultados e avaliacao (2 minutos)

Mostrar:

- curva de treinamento em `docs/curva_treinamento.png`;
- acuracia no teste: **90,91%**;
- matriz de confusao em `docs/matriz_confusao.png`;
- explicar que a base e pequena e desbalanceada.

Ponto honesto para falar:

> A acuracia foi boa, mas a base ainda e pequena. A classe ato_pessoal tem apenas um exemplo, entao a avaliacao dela ainda nao e confiavel. O proximo passo seria aumentar a quantidade de exemplos por classe.

### 5. Demo ao vivo da interface (3 minutos)

Rodar:

```bash
streamlit run app.py
```

Demonstrar as abas:

1. **Classificador:** colar um texto e mostrar classe + confianca.
2. **Busca:** filtrar publicacoes por classe e palavra-chave.
3. **Painel:** mostrar total de publicacoes, classes e distribuicao por rotulo.

Textos para testar na demo:

```text
Pregao eletronico para registro de precos de medicamentos, com empresa vencedora e extrato de contrato.
```

```text
Fica decretado ponto facultativo nas reparticoes publicas municipais.
```

```text
Balancete de receita e despesa, prestacao de contas e execucao orcamentaria do municipio.
```

### 6. Limitacoes e evolucao futura (1 minuto)

Limitações:

- poucos dados rotulados;
- classes desbalanceadas;
- modelo simples;
- algumas publicacoes podem ter texto incompleto quando o PDF nao extrai bem.

Evolucao futura:

- mais publicacoes rotuladas;
- busca semantica;
- alertas automaticos;
- extracao de empresas, valores, datas e secretarias;
- modelo mais forte com LSTM, GRU ou Transformers.

## Divisao sugerida entre integrantes

- **Gabriel:** problema, pipeline e demo da interface.
- **Marcos:** modelo, treinamento e metricas.
- **Willian:** analise de erros, limitacoes e evolucao futura.

## Plano B da demo

Se o Streamlit nao abrir no dia:

- mostrar prints do app rodando;
- abrir o notebook `04_treinamento_avaliacao.ipynb`;
- mostrar `curva_treinamento.png` e `matriz_confusao.png`;
- executar `python src/inferencia.py` no terminal.
