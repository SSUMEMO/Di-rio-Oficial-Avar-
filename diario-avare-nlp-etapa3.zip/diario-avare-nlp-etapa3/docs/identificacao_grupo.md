# Identificação do Grupo

| Campo | Informação |
|---|---|
| Número do Grupo | 8 |
| Turma / Período | 7º termo |
| Integrante 1 | Sem RA - Gabriel Joaquim Carlos de Andrade Rodrigues |
| Integrante 2 | Sem RA - Marcos Paulo Cândido |
| Integrante 3 | Sem RA - Willian Eduardo Novaes |
| Integrante 4 | - |
| Integrante 5 | - |
| Repositório GitHub | https://github.com/SSUMEMO/Di-rio-Oficial-Avar- |
