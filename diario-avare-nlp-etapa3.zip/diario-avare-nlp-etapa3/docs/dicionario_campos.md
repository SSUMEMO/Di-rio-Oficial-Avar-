# Dicionário de Campos - Diário Oficial Inteligente de Avaré

## Identificação do grupo

| Campo | Informação |
|---|---|
| Número do grupo | PREENCHER |
| Turma / Período | Engenharia de Computação - PREENCHER |
| Integrante 1 | RA: PREENCHER - Nome: PREENCHER |
| Integrante 2 | RA: PREENCHER - Nome: PREENCHER |
| Integrante 3 | RA: PREENCHER - Nome: PREENCHER |
| Integrante 4 | RA: PREENCHER - Nome: PREENCHER |
| Integrante 5 | RA: PREENCHER - Nome: PREENCHER |
| Repositório GitHub | https://github.com/SSUMEMO/Di-rio-Oficial-Avar- |

> Antes da entrega, preencher RA, nome dos integrantes, número do grupo e turma/período.

## Base textual

Arquivo: `data/processed/base_textual.csv`

| Campo | Tipo | Formato esperado | Obrigatório | Descrição | Exemplo |
|---|---|---|---|---|---|
| `id` | string | `DOA-YYYY-NNN` | Sim | Identificador único de cada publicação processada. | `DOA-2026-001` |
| `data_publicacao` | string/data | `YYYY-MM-DD` | Sim | Data em que a publicação apareceu no Diário Oficial. | `2026-05-19` |
| `numero_edicao` | inteiro | número da edição | Sim | Número da edição do Semanário/Diário Oficial. | `2736` |
| `tipo_ato` | string | texto controlado | Sim | Tipo formal do ato ou grupo de publicação. | `Lei`, `Decreto`, `Portaria`, `Licitação/Contrato` |
| `titulo` | string | texto livre | Sim | Título, número ou ementa usada para identificar o ato. | `3448 - implantação de espaços sensoriais em praças públicas TEA` |
| `secretaria` | string | texto livre | Não | Secretaria, órgão ou setor responsável pela publicação, quando identificado. | `Secretaria Municipal da Saúde` |
| `texto` | string | texto limpo | Sim | Conteúdo textual extraído e normalizado. Deve preservar acentos e informação relevante. | `Lei nº 3.448...` |
| `url_original` | string | URL completa | Sim | Link de origem para rastreabilidade do documento. | `https://www.dosp.com.br/exibe_do.php?i=ODIwMDky` |
| `rotulo` | string | classe controlada | Sim na amostra | Classe manual ou semiautomática usada para treinamento supervisionado. | `contas_publicas` |

## Valores possíveis para `tipo_ato`

| Valor | Quando usar |
|---|---|
| `Lei` | Publicações identificadas como leis ordinárias. |
| `Lei Complementar` | Publicações identificadas como lei complementar. |
| `Decreto` | Atos identificados como decretos municipais. |
| `Portaria` | Atos administrativos do tipo portaria. |
| `Licitação/Contrato` | Avisos, pregões, chamamentos, adjudicações, homologações, atas e contratos. |
| `Outros Atos` | Atas, ofícios, convocações e atos administrativos que não se encaixam nos demais tipos. |

## Valores possíveis para `rotulo`

| Rótulo | Significado | Termos indicativos |
|---|---|---|
| `licitacao_contrato` | Publicações relacionadas a compras públicas, licitações, contratos, atas e credenciamentos. | pregão eletrônico, chamamento público, contrato, ata de registro, adjudicação, homologação |
| `ato_pessoal` | Atos relacionados a servidores, cargos, nomeações, exonerações, enquadramento ou quadro de pessoal. | servidor, cargo, readaptação, enquadramento, quadro de pessoal |
| `decreto` | Atos normativos gerais e publicações legais que não possuem classe específica no enunciado. | dispõe sobre, regulamenta, institui, autoriza |
| `portaria` | Portarias, convocações administrativas e atos internos de organização. | portaria, resolve, convocação, ofício |
| `edital_concurso` | Editais de concurso público ou processo seletivo. | concurso, processo seletivo, inscrições abertas |
| `contas_publicas` | Publicações sobre orçamento, crédito adicional, receita, despesa e contas públicas. | crédito adicional, orçamento, receita, despesa, alíquotas, prestação de contas |

## Observações de qualidade

- Acentos foram preservados para manter a qualidade do português.
- Textos com problemas de codificação foram normalizados.
- Registros sem secretaria clara receberam `Não identificado`.
- As classes foram atribuídas por regras iniciais e devem ser revisadas manualmente antes do treinamento final.
