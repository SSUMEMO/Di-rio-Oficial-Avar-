"""
src/model.py
Etapa 4 - Diario Oficial Inteligente de Avare

Modelo neural simples para classificacao de publicacoes do Diario Oficial.
Arquitetura: Embedding -> media dos vetores -> camadas lineares -> logits.
"""

from __future__ import annotations

import torch
import torch.nn as nn


class ClassificadorDiario(nn.Module):
    """Classificador textual com embeddings para publicacoes do Diario Oficial de Avare."""

    def __init__(self, vocab_size: int, num_classes: int, embed_dim: int = 64, hidden_dim: int = 128, dropout: float = 0.2):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.fc1 = nn.Linear(embed_dim, hidden_dim)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        self.fc2 = nn.Linear(hidden_dim, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Recebe x com shape [batch, max_len] e devolve logits [batch, num_classes]."""
        emb = self.embedding(x)  # [batch, max_len, embed_dim]

        # Media mascarada: ignora tokens <PAD>=0 no calculo da media.
        # Isso preserva a ideia de media dos embeddings, mas evita que padding diminua artificialmente o vetor.
        mascara = (x != 0).unsqueeze(-1).float()  # [batch, max_len, 1]
        soma = (emb * mascara).sum(dim=1)  # [batch, embed_dim]
        quantidade = mascara.sum(dim=1).clamp(min=1.0)  # evita divisao por zero
        media = soma / quantidade

        h = self.relu(self.fc1(media))
        h = self.dropout(h)
        logits = self.fc2(h)
        return logits
