"""
app.py
Interface Streamlit do Diario Oficial Inteligente de Avare.

Para rodar:
    streamlit run app.py
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

from src.inferencia import classificar

ROOT = Path(__file__).resolve().parent
BASE_PATH = ROOT / "data" / "processed" / "amostra_rotulada.csv"

st.set_page_config(
    page_title="Diario Oficial Inteligente de Avare",
    page_icon="📰",
    layout="wide",
)

st.title("Diario Oficial Inteligente de Avare")
st.caption("Classificacao automatica de publicacoes do Diario Oficial com Redes Neurais e PyTorch")

@st.cache_data
def carregar_base():
    if BASE_PATH.exists():
        return pd.read_csv(BASE_PATH)
    return pd.DataFrame(columns=["rotulo", "texto", "data_publicacao", "titulo", "url_original"])

base = carregar_base()
aba_clf, aba_busca, aba_painel = st.tabs(["Classificador", "Busca de publicacoes", "Painel de indicadores"])

with aba_clf:
    st.subheader("Classificar uma publicacao")
    texto = st.text_area(
        "Cole o texto da publicacao aqui:",
        height=220,
        placeholder="Ex.: Pregao eletronico para registro de precos de medicamentos...",
    )

    if st.button("Classificar", type="primary"):
        if texto.strip():
            classe, confianca, ranking = classificar(texto)
            st.success(f"Classe prevista: **{classe}**")
            st.progress(confianca, text=f"Confianca do modelo: {confianca:.0%}")
            st.write("Classes mais provaveis:")
            ranking_df = pd.DataFrame(ranking, columns=["classe", "probabilidade"])
            ranking_df["probabilidade"] = ranking_df["probabilidade"].map(lambda v: f"{v:.2%}")
            st.dataframe(ranking_df, use_container_width=True, hide_index=True)
        else:
            st.warning("Cole um texto antes de classificar.")

with aba_busca:
    st.subheader("Buscar na base rotulada")
    if base.empty:
        st.info("Base nao encontrada ou vazia.")
    else:
        col1, col2 = st.columns(2)
        classe_sel = col1.selectbox("Filtrar por classe:", ["Todas"] + sorted(base["rotulo"].dropna().unique()))
        palavra = col2.text_input("Palavra-chave:")

        resultado = base.copy()
        if classe_sel != "Todas":
            resultado = resultado[resultado["rotulo"] == classe_sel]
        if palavra:
            resultado = resultado[resultado["texto"].astype(str).str.contains(palavra, case=False, na=False)]

        st.write(f"{len(resultado)} publicacoes encontradas")
        colunas = [c for c in ["data_publicacao", "rotulo", "titulo", "texto", "url_original"] if c in resultado.columns]
        st.dataframe(resultado[colunas], use_container_width=True)

with aba_painel:
    st.subheader("Indicadores da base")
    if base.empty:
        st.info("Base nao encontrada ou vazia.")
    else:
        col1, col2, col3 = st.columns(3)
        col1.metric("Publicacoes rotuladas", len(base))
        col2.metric("Classes", base["rotulo"].nunique())
        col3.metric("Acuracia no teste", "90,91%")

        st.write("Distribuicao por classe")
        st.bar_chart(base["rotulo"].value_counts())

        if "data_publicacao" in base.columns:
            serie = pd.to_datetime(base["data_publicacao"], errors="coerce").dt.to_period("M").astype(str)
            evolucao = serie.value_counts().sort_index()
            st.write("Evolucao mensal das publicacoes rotuladas")
            st.line_chart(evolucao)
