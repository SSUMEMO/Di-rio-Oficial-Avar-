# src/preprocess.py
# Responsavel: limpeza, normalizacao e rotulagem inicial dos textos.
# Projeto: Diario Oficial Inteligente de Avare - Etapa 2

from __future__ import annotations

import re
import unicodedata


ROTULOS_VALIDOS = {
    "licitacao_contrato",
    "ato_pessoal",
    "decreto",
    "portaria",
    "edital_concurso",
    "contas_publicas",
}


def corrigir_mojibake(valor):
    """Corrige textos importados com problema de codificacao, como 'Ã§'."""
    if valor is None:
        return ""
    if not isinstance(valor, str):
        return valor

    texto = valor.replace("\ufeff", "").replace("ï»¿", "").strip()

    if any(marcador in texto for marcador in ("Ã", "Â", "�")):
        try:
            corrigido = texto.encode("latin1").decode("utf-8")
            if corrigido.count("Ã") <= texto.count("Ã"):
                texto = corrigido
        except (UnicodeEncodeError, UnicodeDecodeError):
            pass

    return texto.strip()


def limpar_texto(texto: str) -> str:
    """Remove ruidos comuns de PDF/HTML sem apagar informacao util."""
    texto = corrigir_mojibake(texto)
    texto = unicodedata.normalize("NFC", texto)

    # Espacos repetidos e tabs
    texto = re.sub(r"[ \t]+", " ", texto)

    # Muitas quebras de linha seguidas viram no maximo duas
    texto = re.sub(r"\n{3,}", "\n\n", texto)

    # Remove linhas isoladas que parecem numero de pagina
    texto = re.sub(r"^\s*\d+\s*$", "", texto, flags=re.MULTILINE)

    # Remove caracteres invisiveis de controle
    texto = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", texto)

    # Remove rodape padrao repetido do Diario Oficial, quando aparecer muitas vezes
    texto = re.sub(
        r"Semanário Oficial assinado digitalmente.*?integridade\.?",
        "",
        texto,
        flags=re.IGNORECASE | re.DOTALL,
    )

    return texto.strip()


def normalizar_texto(texto: str) -> str:
    """Normaliza Unicode e pequenos separadores mantendo acentos."""
    texto = unicodedata.normalize("NFC", texto or "")
    texto = texto.replace("--", "-")
    texto = texto.replace("–", "-")
    texto = re.sub(r"[ ]{2,}", " ", texto)
    return texto.strip()


def processar(texto: str) -> str:
    """Pipeline unico de limpeza e normalizacao."""
    return normalizar_texto(limpar_texto(texto))


def inferir_rotulo(tipo_ato: str, titulo: str, texto: str = "") -> str:
    """Atribui um rotulo inicial por palavras-chave para revisar manualmente."""
    base = f"{tipo_ato} {titulo} {texto}".lower()

    if any(p in base for p in [
        "pregão", "pregao", "licita", "contrato", "contratação",
        "chamamento", "credenciamento", "ata de registro",
        "dispensa", "inexigibilidade", "adjudica", "homologa"
    ]):
        return "licitacao_contrato"

    if any(p in base for p in ["concurso", "processo seletivo", "inscriç", "edital"]):
        return "edital_concurso"

    if any(p in base for p in [
        "servidor", "servidores", "nomear", "exonerar", "cargo",
        "quadro de pessoal", "readaptação", "enquadramento", "reenquadramento"
    ]):
        return "ato_pessoal"

    if "portaria" in base:
        return "portaria"

    if any(p in base for p in [
        "crédito", "credito", "orçamento", "orçament", "receita",
        "despesa", "balancete", "prestação de contas", "prestacao de contas",
        "contribuição previdenciária", "contribuicao previdenciaria"
    ]):
        return "contas_publicas"

    if "decreto" in base:
        return "decreto"

    # As leis da coleta nao possuem classe propria no enunciado.
    # Por isso, atos normativos gerais ficam como "decreto" para manter os rotulos sugeridos.
    return "decreto"


def texto_fallback(tipo_ato: str, titulo: str, data_publicacao: str, secretaria: str, rotulo: str) -> str:
    """Texto minimo estruturado quando a extracao do PDF nao retorna trecho suficiente."""
    secretaria = secretaria or "Não identificado"
    return processar(
        f"{tipo_ato}. Publicação de {data_publicacao}. "
        f"Título/ementa: {titulo}. Secretaria/órgão: {secretaria}. "
        f"Registro classificado inicialmente como {rotulo}. "
        "Texto gerado como fallback para manter a rastreabilidade do item coletado; "
        "recomenda-se revisar com o PDF original antes do treinamento do modelo."
    )
