"""
src/dataset.py
Etapa 3 - Diario Oficial Inteligente de Avare

Este modulo transforma publicacoes rotuladas em tensores para uso no PyTorch.
Ele inclui tokenizacao, codificacao com vocabulario, Dataset e DataLoader.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import pandas as pd
import torch
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset

STOPWORDS = {
    "de", "da", "do", "das", "dos", "e", "o", "a", "os", "as", "para",
    "no", "na", "nos", "nas", "que", "em", "um", "uma", "com", "por",
    "ao", "aos", "se", "sua", "seu", "suas", "seus", "pela", "pelo",
    "pelas", "pelos", "ou", "à", "às", "como", "mais", "ser", "são",
    "foi", "sem", "sob", "entre", "sobre", "após", "até", "este", "esta",
    "estes", "estas",
}


def tokenizar(texto: str, remover_stopwords: bool = True) -> List[str]:
    """Converte texto em tokens: minusculas, sem pontuacao/numeros e com acentos preservados."""
    texto = str(texto).lower()
    texto = re.sub(r"[^a-zà-ú\s]", " ", texto)
    tokens = texto.split()
    if remover_stopwords:
        tokens = [t for t in tokens if t not in STOPWORDS and len(t) > 1]
    else:
        tokens = [t for t in tokens if len(t) > 1]
    return tokens


def construir_vocab(textos: Iterable[str], min_freq: int = 2) -> Dict[str, int]:
    """Constroi vocabulario token -> indice usando apenas os textos informados."""
    contador: Counter[str] = Counter()
    for texto in textos:
        contador.update(tokenizar(texto))

    vocab = {"<PAD>": 0, "<UNK>": 1}
    for token, freq in contador.most_common():
        if freq >= min_freq:
            vocab[token] = len(vocab)
    return vocab


def codificar_texto(texto: str, vocab: Dict[str, int], max_len: int = 60) -> List[int]:
    """Converte um texto em uma lista de indices com padding/truncamento."""
    ids = [vocab.get(token, vocab["<UNK>"]) for token in tokenizar(texto)]
    ids = ids[:max_len]
    ids += [vocab["<PAD>"]] * (max_len - len(ids))
    return ids


def salvar_json(objeto: dict, caminho: str | Path) -> None:
    caminho = Path(caminho)
    caminho.parent.mkdir(parents=True, exist_ok=True)
    with caminho.open("w", encoding="utf-8") as arquivo:
        json.dump(objeto, arquivo, ensure_ascii=False, indent=2)


def carregar_json(caminho: str | Path) -> dict:
    with Path(caminho).open("r", encoding="utf-8") as arquivo:
        return json.load(arquivo)


def divisao_treino_teste(
    df: pd.DataFrame,
    test_size: float = 0.2,
    random_state: int = 42,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Divide em treino e teste com estratificacao quando possivel.

    Observacao: uma classe com apenas 1 registro nao pode ser estratificada pelo
    train_test_split. Nesse caso, os registros raros ficam no treino e a divisao
    estratificada e aplicada nas demais classes. Essa decisao evita erro e preserva
    todos os dados rotulados para aprendizado.
    """
    contagem = df["rotulo"].value_counts()
    classes_raras = contagem[contagem < 2].index.tolist()

    raros_df = df[df["rotulo"].isin(classes_raras)].copy()
    principal_df = df[~df["rotulo"].isin(classes_raras)].copy()

    if principal_df["rotulo"].nunique() > 1:
        treino_df, teste_df = train_test_split(
            principal_df,
            test_size=test_size,
            random_state=random_state,
            stratify=principal_df["rotulo"],
        )
        treino_df = pd.concat([treino_df, raros_df], ignore_index=True)
    else:
        treino_df, teste_df = train_test_split(
            df,
            test_size=test_size,
            random_state=random_state,
            shuffle=True,
        )

    return treino_df.reset_index(drop=True), teste_df.reset_index(drop=True)


class DiarioDataset(Dataset):
    """Dataset das publicacoes do Diario Oficial de Avare."""

    def __init__(self, dataframe: pd.DataFrame, vocab: Dict[str, int], label2id: Dict[str, int], max_len: int = 60):
        self.textos = dataframe["texto"].astype(str).tolist()
        self.rotulos = dataframe["rotulo"].astype(str).tolist()
        self.vocab = vocab
        self.label2id = label2id
        self.max_len = max_len

    def __len__(self) -> int:
        return len(self.textos)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        ids = codificar_texto(self.textos[idx], self.vocab, self.max_len)
        rotulo_id = self.label2id[self.rotulos[idx]]
        x = torch.tensor(ids, dtype=torch.long)
        y = torch.tensor(rotulo_id, dtype=torch.long)
        return x, y


def criar_dataloaders(
    csv_path: str | Path = "data/processed/amostra_rotulada.csv",
    vocab_path: str | Path = "data/processed/vocab.json",
    label_map_path: str | Path = "data/processed/label_map.json",
    max_len: int = 60,
    batch_size: int = 8,
) -> Tuple[DataLoader, DataLoader, Dict[str, int], Dict[str, int]]:
    """Carrega CSV, mapeamentos e retorna DataLoaders de treino e teste."""
    df = pd.read_csv(csv_path).dropna(subset=["texto", "rotulo"])
    vocab = carregar_json(vocab_path)
    label2id = carregar_json(label_map_path)

    treino_df, teste_df = divisao_treino_teste(df)
    treino_ds = DiarioDataset(treino_df, vocab, label2id, max_len=max_len)
    teste_ds = DiarioDataset(teste_df, vocab, label2id, max_len=max_len)

    treino_loader = DataLoader(treino_ds, batch_size=batch_size, shuffle=True)
    teste_loader = DataLoader(teste_ds, batch_size=batch_size, shuffle=False)
    return treino_loader, teste_loader, vocab, label2id


if __name__ == "__main__":
    treino_loader, teste_loader, vocab, label2id = criar_dataloaders()
    x_lote, y_lote = next(iter(treino_loader))
    print("Tamanho do vocabulario:", len(vocab))
    print("Mapa de rotulos:", label2id)
    print("Formato X:", tuple(x_lote.shape))
    print("Formato y:", tuple(y_lote.shape))
    print("Rotulos do lote:", y_lote.tolist())
