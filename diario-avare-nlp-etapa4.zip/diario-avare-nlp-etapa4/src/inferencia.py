"""
src/inferencia.py
Etapa 4 - Diario Oficial Inteligente de Avare

Funcao de inferencia para classificar textos novos usando o modelo treinado.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Tuple

import torch

try:
    from src.dataset import codificar_texto
    from src.model import ClassificadorDiario
except ModuleNotFoundError:  # permite executar de dentro da pasta src em testes locais
    from dataset import codificar_texto
    from model import ClassificadorDiario

ROOT = Path(__file__).resolve().parents[1]
VOCAB_PATH = ROOT / "data" / "processed" / "vocab.json"
LABEL_MAP_PATH = ROOT / "data" / "processed" / "label_map.json"
MODEL_PATH = ROOT / "models" / "modelo.pt"
MAX_LEN = 60


def carregar_json(caminho: Path) -> dict:
    with caminho.open("r", encoding="utf-8") as arquivo:
        return json.load(arquivo)


def carregar_modelo():
    """Carrega vocabulario, mapa de rotulos e pesos treinados."""
    vocab: Dict[str, int] = carregar_json(VOCAB_PATH)
    label2id: Dict[str, int] = carregar_json(LABEL_MAP_PATH)
    id2label = {int(i): classe for classe, i in label2id.items()}

    modelo = ClassificadorDiario(vocab_size=len(vocab), num_classes=len(label2id))
    state_dict = torch.load(MODEL_PATH, map_location="cpu")
    modelo.load_state_dict(state_dict)
    modelo.eval()
    return modelo, vocab, label2id, id2label


_MODELO = None
_VOCAB = None
_LABEL2ID = None
_ID2LABEL = None


def _get_recursos():
    global _MODELO, _VOCAB, _LABEL2ID, _ID2LABEL
    if _MODELO is None:
        _MODELO, _VOCAB, _LABEL2ID, _ID2LABEL = carregar_modelo()
    return _MODELO, _VOCAB, _LABEL2ID, _ID2LABEL


def classificar(texto: str, top_k: int = 3) -> Tuple[str, float, List[Tuple[str, float]]]:
    """
    Classifica um texto e retorna classe, confianca e ranking das classes mais provaveis.

    Retorno:
        (classe_prevista, confianca, top_classes)
    """
    modelo, vocab, _label2id, id2label = _get_recursos()
    ids = codificar_texto(texto, vocab, max_len=MAX_LEN)
    x = torch.tensor([ids], dtype=torch.long)

    with torch.no_grad():
        logits = modelo(x)
        probs = torch.softmax(logits, dim=1)[0]
        conf, pred = probs.max(dim=0)

    k = min(top_k, len(id2label))
    valores, indices = torch.topk(probs, k=k)
    ranking = [(id2label[int(i)], float(v)) for v, i in zip(valores, indices)]
    return id2label[int(pred)], float(conf), ranking


if __name__ == "__main__":
    exemplos = [
        "Pregao eletronico para registro de precos de medicamentos e contratacao de empresa vencedora.",
        "Fica decretado ponto facultativo nas reparticoes publicas municipais.",
        "Portaria resolve designar servidor para responder por setor administrativo.",
        "Balancete de receita e despesa, prestacao de contas e orcamento municipal.",
        "Nomear servidor para cargo em comissao junto a secretaria municipal.",
    ]
    for exemplo in exemplos:
        classe, confianca, ranking = classificar(exemplo)
        print(f"Texto: {exemplo[:70]}...")
        print(f"Classe: {classe} | confianca: {confianca:.2%}")
        print("Top classes:", ranking)
        print("-" * 80)
