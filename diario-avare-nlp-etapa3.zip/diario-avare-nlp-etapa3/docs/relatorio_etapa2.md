# Relatório da Etapa 2 - Extração, Limpeza e Estruturação

## Identificação do Grupo

| Campo | Informação |
|---|---|
| Número do Grupo | 8 |
| Turma / Período | 7º termo |
| Integrante 1 | Sem RA - Gabriel Joaquim Carlos de Andrade Rodrigues |
| Integrante 2 | Sem RA - Marcos Paulo Cândido |
| Integrante 3 | Sem RA - Willian Eduardo Novaes |
| Repositório GitHub | https://github.com/SSUMEMO/Di-rio-Oficial-Avar- |

## 1. Objetivo

A Etapa 2 transforma a lista de publicações coletadas na Etapa 1 em uma base textual estruturada, limpa e rotulada, pronta para uso nas etapas de NLP e treinamento de modelos.

## 2. Arquivos gerados

| Entregável | Caminho | Situação |
|---|---|---|
| Base textual limpa | `data/processed/base_textual.csv` | Gerado |
| Dicionário de campos | `docs/dicionario_campos.md` | Gerado |
| Amostra rotulada | `data/processed/amostra_rotulada.csv` | Gerado |
| Script de extração | `src/extract_text.py` | Gerado |
| Script de pré-processamento | `src/preprocess.py` | Gerado |
| Banco SQLite opcional | `data/processed/diario_avare.db` | Gerado |

## 3. Metodologia

A planilha `data/raw/diario_avare.xlsx` foi usada como base inicial, contendo datas, edições, títulos, tipos de ato, URLs e secretarias. Os textos foram estruturados em campos padronizados, com correção de codificação, normalização Unicode e remoção de ruídos simples.

O script `extract_text.py` foi preparado para baixar e processar publicações em PDF ou HTML. Para PDFs digitais, usa `pdfplumber`; para páginas HTML, usa `BeautifulSoup`. O script também tenta recortar o trecho correto do Diário Oficial com base no número/título do ato.

O script `preprocess.py` concentra as funções de limpeza, normalização, correção de mojibake e rotulagem inicial por palavras-chave.

## 4. Rotulagem

A amostra rotulada contém mais de 40 registros e pelo menos 3 classes distintas, atendendo ao requisito mínimo da etapa. As classes usadas foram:

- `decreto`
- `contas_publicas`
- `licitacao_contrato`
- `portaria`
- `ato_pessoal`

A rotulagem inicial foi feita por regras de palavras-chave. Recomenda-se revisão manual antes de usar a base para treinamento supervisionado.

## 5. Observações sobre PDFs escaneados

Caso algum PDF não permita extração textual com `pdfplumber`, o script registra aviso no terminal. Para essa situação, a próxima melhoria recomendada é incluir OCR com `pytesseract`.

## 6. Limitações e próximos passos

- Alguns atos classificados como `decreto` são atos normativos gerais, pois o enunciado não trouxe uma classe específica para `lei`.
- O campo `secretaria` depende dos metadados coletados ou da identificação no texto.
- Para a Etapa 3, recomenda-se revisar manualmente os rótulos e padronizar termos antes da vetorização.
