# Relatório da Etapa 3 - NLP e Preparação para PyTorch

## Identificação do grupo

- **Projeto:** Diário Oficial Inteligente de Avaré
- **Disciplina:** Redes Neurais e IA Aplicada
- **Grupo:** 8
- **Turma / período:** 7º termo - Engenharia de Computação
- **Integrante 1:** Sem RA | Gabriel Joaquim Carlos de Andrade Rodrigues
- **Integrante 2:** Sem RA | Marcos Paulo Cândido
- **Integrante 3:** Sem RA | Willian Eduardo Novaes
- **Repositório GitHub:** https://github.com/SSUMEMO/Di-rio-Oficial-Avar-

## 1. Objetivo da etapa

A Etapa 3 transforma a base textual limpa e rotulada da Etapa 2 em dados numéricos compatíveis com redes neurais em PyTorch. Para isso, foram realizadas análise exploratória, tokenização, construção de vocabulário, codificação dos textos, codificação dos rótulos e criação da classe `DiarioDataset`.

## 2. Base utilizada

O arquivo de entrada utilizado foi `data/processed/amostra_rotulada.csv`, contendo **53 registros rotulados**. A base possui as colunas principais `texto` e `rotulo`, além dos metadados da publicação.

## 3. Análise exploratória dos dados

### Distribuição das classes

| rotulo             |   quantidade |
|:-------------------|-------------:|
| decreto            |           23 |
| contas_publicas    |           15 |
| licitacao_contrato |           10 |
| portaria           |            4 |
| ato_pessoal        |            1 |

A classe mais frequente foi **decreto**, com 23 registros. A classe menos frequente foi **ato_pessoal**, com 1 registro. Essa diferença mostra desbalanceamento na base e foi registrada para orientar a Etapa 4.

O gráfico `docs/distribuicao_classes.png` mostra visualmente essa distribuição.

### Comprimento dos textos

A análise foi feita após a tokenização para NLP. Resumo do número de tokens por publicação:

- Mínimo: 40
- Média: 49.77
- Mediana: 50.00
- Máximo: 60
- Percentil 95: 58.00

Com base nisso, foi escolhido **max_len = 60**, pois cobre praticamente todos os textos sem desperdiçar memória com padding excessivo. O gráfico `docs/comprimento_textos.png` documenta essa decisão.

### Termos mais frequentes

Termos mais frequentes após minúsculas, remoção de pontuação/números e stopwords:

| termo       |   frequencia |
|:------------|-------------:|
| ato         |           91 |
| secretaria  |           72 |
| órgão       |           71 |
| municipal   |           66 |
| data        |           57 |
| ementa      |           53 |
| artigo      |           53 |
| final       |           53 |
| entra       |           53 |
| vigor       |           53 |
| publicação  |           53 |
| revogadas   |           53 |
| disposições |           53 |
| contrário   |           53 |
| dispõe      |           41 |

Os termos mais frequentes confirmam que a base contém linguagem administrativa e oficial, com palavras como `ato`, `secretaria`, `órgão`, `municipal`, `ementa` e `publicação`.

## 4. Pré-processamento para NLP e tokenização

Nesta etapa foram adotadas as seguintes decisões:

- conversão do texto para minúsculas;
- remoção de pontuação e números soltos;
- preservação de acentos do português;
- remoção de stopwords básicas em português;
- remoção de tokens com apenas uma letra;
- tokenização por separação em espaços.

A decisão de remover stopwords foi tomada porque os textos possuem muitas palavras funcionais repetidas, como `de`, `da`, `do`, `para` e `com`. A remoção reduz o vocabulário e deixa mais destaque para termos importantes das classes.

## 5. Vocabulário e codificação dos textos

O vocabulário foi construído com os textos de treino, evitando vazamento de dados do teste. Foram utilizados dois tokens especiais obrigatórios:

- `<PAD>` com índice `0`, usado para preencher sequências curtas;
- `<UNK>` com índice `1`, usado para palavras desconhecidas.

Foram mantidos tokens com frequência mínima igual a 2. O vocabulário final possui **159 tokens** e foi salvo em:

```text
data/processed/vocab.json
```

Cada publicação foi convertida em uma sequência de índices de tamanho fixo `max_len = 60`. Textos maiores foram truncados e textos menores foram preenchidos com `<PAD>`.

## 6. Codificação dos rótulos

Os rótulos foram codificados em números usando ordenação alfabética das classes. O mapeamento gerado foi:

```json
{
  "ato_pessoal": 0,
  "contas_publicas": 1,
  "decreto": 2,
  "licitacao_contrato": 3,
  "portaria": 4
}
```

O arquivo foi salvo em:

```text
data/processed/label_map.json
```

## 7. Divisão treino/teste

A divisão foi configurada com `test_size = 0.2` e `random_state = 42`. Como a classe `ato_pessoal` possui apenas 1 registro, ela não pode participar de uma divisão estratificada tradicional, pois o `train_test_split` exige pelo menos 2 exemplos por classe. A decisão adotada foi:

- manter classes com menos de 2 registros no treino;
- aplicar divisão estratificada nas demais classes.

Com isso, a base ficou com:

- **Treino:** 42 registros
- **Teste:** 11 registros

Essa decisão preserva todos os dados disponíveis e evita erro técnico na divisão estratificada.

## 8. Dataset PyTorch

Foi criado o arquivo `src/dataset.py` com:

- função `tokenizar`;
- função `construir_vocab`;
- função `codificar_texto`;
- função `divisao_treino_teste`;
- classe `DiarioDataset` herdando de `torch.utils.data.Dataset`;
- função `criar_dataloaders`.

O método `__getitem__` retorna:

- `x`: tensor com shape `[max_len]`;
- `y`: tensor com o índice inteiro da classe.

Teste realizado com `DataLoader`:

```text
Tamanho do vocabulario: 159
Mapa de rotulos: {'ato_pessoal': 0, 'contas_publicas': 1, 'decreto': 2, 'licitacao_contrato': 3, 'portaria': 4}
Formato X: (8, 60)
Formato y: (8,)
Rotulos do lote: [4, 3, 1, 2, 0, 1, 1, 3]
```

O resultado confirma que o lote de entrada está no formato esperado para a Etapa 4.

## 9. Comparação com PyTorch-NLP

Foi incluído no notebook um exemplo didático com `WhitespaceEncoder` e `LabelEncoder` da biblioteca PyTorch-NLP. A implementação manual e a biblioteca têm objetivos parecidos: transformar texto e rótulos em números.

Comparação:

| Critério | Implementação manual | PyTorch-NLP |
|---|---|---|
| Controle da limpeza | Alto, pois definimos regex e stopwords | Menor, depende dos encoders usados |
| Didática | Melhor para entender cada etapa | Melhor para visualizar ferramentas prontas |
| Reprodutibilidade | Garantida por `vocab.json` e `label_map.json` | Depende da versão da biblioteca |
| Flexibilidade | Alta | Boa, mas mais fechada |

A implementação manual foi mantida como principal porque atende diretamente ao objetivo pedagógico da Etapa 3 e deixa o pipeline transparente para a Etapa 4.

## 10. Entregáveis gerados

- `notebooks/03_analise_exploratoria.ipynb`
- `data/processed/vocab.json`
- `data/processed/label_map.json`
- `src/dataset.py`
- `docs/relatorio_etapa3.md`
- `docs/distribuicao_classes.png`
- `docs/comprimento_textos.png`
- `docs/termos_frequentes.png`

## 11. Conclusão

A Etapa 3 deixou a base pronta para ser usada por um modelo neural na Etapa 4. Os textos foram analisados, tokenizados e convertidos em sequências numéricas com padding. Os rótulos foram codificados, o vocabulário foi salvo e a classe `DiarioDataset` foi testada com `DataLoader`, retornando tensores no formato correto.
