# Diário Oficial Inteligente de Avaré - Etapa 1

Projeto prático da disciplina **Redes Neurais e IA Aplicada**.

## Identificação do grupo

> Preencher antes da entrega.

- Número do grupo: **PREENCHER**
- Turma / Período: **PREENCHER**
- Integrante 1 (RA | Nome): **PREENCHER | Gabriel Joaquim Carlos de Andrade Rodrigues**
- Integrante 2 (RA | Nome): **PREENCHER**
- Integrante 3 (RA | Nome): **PREENCHER**
- Integrante 4 (RA | Nome): **PREENCHER**
- Integrante 5 (RA | Nome): **PREENCHER**
- Repositório GitHub: **PREENCHER**

## Entregáveis da Semana 1

- `relatorio_exploracao.md` e `relatorio_exploracao.pdf`: relatório de exploração da fonte.
- `src/scraper.py`: script inicial de coleta.
- `data/diario_avare.csv`: lista preliminar com mais de 20 publicações.

## Como configurar

```bash
python -m venv venv

# Windows
venv\Scriptsctivate

# Linux/Mac
source venv/bin/activate

pip install -r requirements.txt
```

## Como rodar o scraper

```bash
python src/scraper.py --limite 20
```

Para coletar mais registros:

```bash
python src/scraper.py --categorias Leis Decretos Portarias --limite 50
```

O arquivo será salvo em:

```txt
data/diario_avare.csv
```

## Estrutura

```txt
diario-avare-nlp/
├── data/
│   ├── raw/
│   ├── processed/
│   └── diario_avare.csv
├── notebooks/
├── src/
│   └── scraper.py
├── requirements.txt
├── README.md
├── relatorio_exploracao.md
└── relatorio_exploracao.pdf
```

## Observação importante

Antes de entregar, preencher os campos de identificação do grupo. O documento da disciplina informa que entregas sem identificação completa não serão avaliadas.
