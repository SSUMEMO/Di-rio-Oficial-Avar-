# Identificação do Grupo - Etapa 3

- **Projeto:** Diário Oficial Inteligente de Avaré
- **Etapa:** 3 - NLP e Preparação para PyTorch
- **Grupo:** 8
- **Turma / Período:** 7º termo - Engenharia de Computação
- **Integrante 1:** Sem RA | Gabriel Joaquim Carlos de Andrade Rodrigues
- **Integrante 2:** Sem RA | Marcos Paulo Cândido
- **Integrante 3:** Sem RA | Willian Eduardo Novaes
- **Integrante 4:** Não se aplica
- **Integrante 5:** Não se aplica
- **Repositório GitHub:** https://github.com/SSUMEMO/Di-rio-Oficial-Avar-
