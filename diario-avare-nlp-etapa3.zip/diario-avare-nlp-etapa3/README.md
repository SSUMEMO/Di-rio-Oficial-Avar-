# Diário Oficial Inteligente de Avaré - Etapas 1, 2 e 3

Projeto prático da disciplina **Redes Neurais e IA Aplicada** - FEAP.

## Identificação

- **Grupo:** 8
- **Turma / Período:** 7º termo - Engenharia de Computação
- **Integrantes:**
  - Sem RA | Gabriel Joaquim Carlos de Andrade Rodrigues
  - Sem RA | Marcos Paulo Cândido
  - Sem RA | Willian Eduardo Novaes

## Etapa 3 - NLP e Preparação para PyTorch

Nesta etapa, a base textual limpa e rotulada da Etapa 2 foi transformada em dados numéricos para uso em redes neurais com PyTorch.

### Entregáveis principais

- `notebooks/03_analise_exploratoria.ipynb`
- `data/processed/vocab.json`
- `data/processed/label_map.json`
- `src/dataset.py`
- `docs/relatorio_etapa3.md`

### Como testar o Dataset PyTorch

Instale as dependências:

```bash
pip install -r requirements.txt
```

Execute o teste:

```bash
python src/dataset.py
```

Saída esperada aproximada:

```text
Tamanho do vocabulario: 159
Formato X: (8, 60)
Formato y: (8,)
```

## Observação técnica

A classe `ato_pessoal` possui apenas 1 registro na amostra. Por isso, para evitar erro na divisão estratificada, registros de classes com menos de 2 exemplos foram mantidos no treino, e a estratificação foi aplicada nas demais classes.
