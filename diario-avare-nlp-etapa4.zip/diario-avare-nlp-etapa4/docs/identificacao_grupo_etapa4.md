# Identificacao do Grupo - Etapa 4

**Projeto:** Diario Oficial Inteligente de Avare  
**Disciplina:** Redes Neurais e IA Aplicada  
**Instituicao:** FEAP - Engenharia de Computacao  
**Grupo:** 8  
**Turma / Periodo:** 7º Termo - Engenharia da Computacao  
**Repositorio GitHub:** https://github.com/SSUMEMO/Di-rio-Oficial-Avar-

| Integrante | RA | Nome |
|---|---|---|
| 1 | Sem RA | Gabriel Joaquim Carlos de Andrade Rodrigues |
| 2 | Sem RA | Marcos Paulo Candido |
| 3 | Sem RA | Willian Eduardo Novaes |
