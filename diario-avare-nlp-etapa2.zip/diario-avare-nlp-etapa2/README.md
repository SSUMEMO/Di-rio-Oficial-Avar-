# Diário Oficial Inteligente de Avaré - Etapa 2

Repositório da Etapa 2 do projeto de Redes Neurais e IA Aplicada.

## Objetivo

Extrair, limpar, estruturar e rotular publicações do Diário Oficial de Avaré para formar uma base textual usada nas etapas seguintes de NLP e modelagem.

## Estrutura

```text
data/
  raw/
    diario_avare.xlsx
    documentos/
  processed/
    base_textual.csv
    amostra_rotulada.csv
    diario_avare.db
docs/
  dicionario_campos.md
  relatorio_etapa2.md
src/
  extract_text.py
  preprocess.py
requirements.txt
```

## Como executar

1. Criar ambiente virtual:

```bash
python -m venv .venv
```

2. Ativar o ambiente:

```bash
# Windows
.venv\Scripts\activate

# Linux/Mac
source .venv/bin/activate
```

3. Instalar dependências:

```bash
pip install -r requirements.txt
```

4. Gerar a base textual:

```bash
python src/extract_text.py --input data/raw/diario_avare.xlsx --output data/processed --sample-size 40
```

## Entregáveis

- `data/processed/base_textual.csv`
- `docs/dicionario_campos.md`
- `data/processed/amostra_rotulada.csv`
- `src/extract_text.py`
- `src/preprocess.py`

## Observação importante

Antes da entrega, preencher a identificação do grupo nos documentos e confirmar se o GitHub usado é o mesmo da Etapa 1.
